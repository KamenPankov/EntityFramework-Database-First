﻿using SoftUni.Data;
using SoftUni.Models;
using System;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Collections.Generic;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SoftUniContext softUniContext = new SoftUniContext();

            Console.WriteLine(GetEmployeesFullInformation(softUniContext));
        }

        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            StringBuilder stringBuilder = new StringBuilder();

            //IQueryable<Employee> employees = from employee in context.Employees
            //                                 orderby employee.EmployeeId
            //                                 select employee;

            //foreach (Employee item in employees)
            //{
            //    stringBuilder.AppendLine(string.Format($"{item.FirstName} {item.LastName} {item.MiddleName} {item.JobTitle} {item.Salary:f2}"));
            //}
            var employees = context.Employees
                .OrderBy(e => e.EmployeeId)
                .Select(e => new
                {
                    Name = string.Join(" ", e.FirstName, e.LastName, e.MiddleName),
                    JobTitle = e.JobTitle,
                    Salary = e.Salary
                });

            foreach (var item in employees)
            {
                stringBuilder.AppendLine(string.Format($"{item.Name} {item.JobTitle} {item.Salary:f2}"));
            }

            return stringBuilder.ToString().TrimEnd();
        }

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            StringBuilder stringBuilder = new StringBuilder();

            IQueryable<Employee> employees = from employee in context.Employees
                                             where employee.Salary > 50000
                                             orderby employee.FirstName
                                             select employee;

            foreach (Employee item in employees)
            {
                stringBuilder.AppendLine($"{item.FirstName} - {item.Salary:f2}");
            }

            return stringBuilder.ToString().TrimEnd();
        }

        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            StringBuilder stringBuilder = new StringBuilder();

            IQueryable<Employee> employees = from employee in context.Employees
                                             where employee.Department.Name == "Research and Development"
                                             orderby employee.Salary, employee.FirstName descending
                                             select employee;

            foreach (Employee item in employees)
            {
                stringBuilder.AppendLine($"{item.FirstName} {item.LastName} from Research and Development - ${item.Salary:f2}");
            }

            return stringBuilder.ToString().TrimEnd();
        }

        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            StringBuilder stringBuilder = new StringBuilder();

            string employeeLastName = "Nakov";

            Address newAddress = new Address { AddressText = "Vitoshka 15", TownId = 4 };
            context.Addresses.Add(newAddress);


            Employee employee = context.Employees.FirstOrDefault(e => e.LastName == employeeLastName);
            if (employee != null)
            {
                employee.Address = newAddress;
            }

            context.SaveChanges();


            IQueryable<Address> employeesAddress = from empl in context.Employees
                                             orderby empl.AddressId descending
                                             select empl.Address;
            int countLines = 1;

            foreach (Address item in employeesAddress)
            {                
                stringBuilder.AppendLine(item.AddressText);
                if (countLines == 10)
                {
                    break;
                }

                countLines++;
            }

            return stringBuilder.ToString().TrimEnd();
        }

        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            StringBuilder stringBuilder = new StringBuilder();

            var employees = from ep in context.EmployeesProjects
                            join e in context.Employees
                            on ep.EmployeeId equals e.EmployeeId
                            join em in context.Employees
                            on e.ManagerId equals em.EmployeeId
                            join p in context.Projects
                            on ep.ProjectId equals p.ProjectId
                            where p.StartDate.Year >= 2001 && p.StartDate.Year <= 2003    
                            select new
                            {     
                                ep,
                                e,
                                em,
                                p
                            }  into elements group elements by elements.ep.Employee into grouped select grouped;

            int countEmployees = 1;

            foreach (var item in employees)
            {
                stringBuilder.AppendLine($"{item.Key.FirstName} {item.Key.LastName} - Manager: {item.Key.Manager.FirstName} {item.Key.Manager.LastName}");

                foreach (var project in item.Key.EmployeesProjects)
                {
                    string endDate;
                    if (project.Project.EndDate == null)
                    {
                        endDate = "not finished";
                    }
                    else
                    {
                        endDate = ((DateTime)project.Project.EndDate).ToString("M/d/yyyy h:mm:ss tt");
                    }
                    stringBuilder.AppendLine($"--{project.Project.Name} - {project.Project.StartDate.ToString("M/d/yyyy h:mm:ss tt")} - {endDate}");
                }

                if (countEmployees == 10)
                {
                    break;
                }

                countEmployees++;
            }
           
            return stringBuilder.ToString().TrimEnd();
        }

        public static string GetAddressesByTown(SoftUniContext context)
        {
            StringBuilder stringBuilder = new StringBuilder();


            var query = (from a in context.Addresses
                        join t in context.Towns
                        on a.TownId equals t.TownId
                        orderby a.Employees.Count descending, t.Name, a.AddressText
                        select new { a, t, emplCount = a.Employees.Count() }).Take(10);

            foreach (var item in query)
            {
                stringBuilder.AppendLine($"{item.a.AddressText}, {item.t.Name} - {item.emplCount} emloyees");
            }
            
            return stringBuilder.ToString().TrimEnd();
        }

        public static string GetEmployee147(SoftUniContext context)
        {
            StringBuilder stringBuilder = new StringBuilder();

            var employee147 = from ep in context.EmployeesProjects
                              join e in context.Employees on ep.EmployeeId equals e.EmployeeId
                              join p in context.Projects on ep.ProjectId equals p.ProjectId
                              where ep.EmployeeId == 147
                              select new
                              {
                                  ep,

                                  e,
                                  p
                              } into elements group elements by elements.ep.Employee into grouped select grouped;

            foreach (var item in employee147)
            {
                stringBuilder.AppendLine($"{item.Key.FirstName} {item.Key.LastName} - {item.Key.JobTitle}");

                foreach (var project in item.Key.EmployeesProjects.OrderBy(p => p.Project.Name))
                {
                    stringBuilder.AppendLine($"{project.Project.Name}");
                }
            }

            return stringBuilder.ToString().TrimEnd();
        }

        //public static string GetDepartmentsWithMoreThan5Employees(SoftUniContext context)
        //{

        //    var query = context.Departments
        //        .Select(d => new
        //        {
        //            DepName = d.Name,
        //            Manager = context.Employees.Select(e => new {e.Manager}),
        //            EmpCount = d.Employees.Count
        //        })
        //        .Where(d => d.EmpCount > 5)
        //        .OrderByDescending(d => d.EmpCount)
        //        .ThenBy(d => d.DepName)
        //        .ToArray();

        //    foreach (var item in collection)
        //    {

        //    }
        //}
    }
}
